package com.abc.orderService.enums;

public enum Deleted {
	DELETED, NOT_DELETED;
}
