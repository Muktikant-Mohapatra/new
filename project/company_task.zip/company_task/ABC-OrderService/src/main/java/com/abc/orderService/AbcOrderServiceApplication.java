package com.abc.orderService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class AbcOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcOrderServiceApplication.class, args);
	}

}
