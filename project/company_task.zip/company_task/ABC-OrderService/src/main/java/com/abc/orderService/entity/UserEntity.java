package com.abc.orderService.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.abc.orderService.enums.Block;
import com.abc.orderService.enums.Deleted;

@Entity(name = "users_details_master")
public class UserEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "first_name")
	private String firstName;
	@Column(name = "last_name")
	private String lastName;
	@Column(name = "email")
	private String email;
	@Column(name = "password")
	private String password;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "logged_in_date_time")
	private Date loggedInDateTime;
	@Enumerated(EnumType.ORDINAL)
	@Column(name = "is_deleted")
	private Deleted isDeleted;
	@Enumerated(EnumType.ORDINAL)
	@Column(name = "block_status")
	private Block blockStatus;
	@OneToMany(mappedBy = "users")
	private List<OrderEntity> orders;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getLoggedInDateTime() {
		return loggedInDateTime;
	}

	public void setLoggedInDateTime(Date loggedInDateTime) {
		this.loggedInDateTime = loggedInDateTime;
	}

	public Deleted getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Deleted isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Block getBlockStatus() {
		return blockStatus;
	}

	public void setBlockStatus(Block blockStatus) {
		this.blockStatus = blockStatus;
	}

	public List<OrderEntity> getOrders() {
		return orders;
	}

	public void setOrders(List<OrderEntity> orders) {
		this.orders = orders;
	}

}
