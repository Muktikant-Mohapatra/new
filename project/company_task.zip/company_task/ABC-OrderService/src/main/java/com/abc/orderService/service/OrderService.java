package com.abc.orderService.service;

import java.util.List;

import com.abc.orderService.dto.OrderDto;
import com.abc.orderService.model.request.OrderRequestModel;

public interface OrderService {

	OrderDto placeOrder(OrderRequestModel orderRequestDto);

	List<OrderDto> findPlacedOrder(Long userid);
   
	
}
