package com.abc.orderService.controller;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.orderService.dto.OrderDto;
import com.abc.orderService.model.request.OrderRequestModel;
import com.abc.orderService.model.response.OrderResponseModel;
import com.abc.orderService.service.OrderService;

@RestController
@RequestMapping(value = "/orders")
public class OrderController {

	private OrderService orderService;

	public OrderController(OrderService orderService) {
		super();
		this.orderService = orderService;
	}

	@PostMapping()
	public ResponseEntity<OrderResponseModel> checkout(@RequestBody OrderRequestModel requestModel) {
		ModelMapper mapper = new ModelMapper();
		OrderRequestModel orderRequestDto = mapper.map(requestModel, OrderRequestModel.class);
		OrderDto placedOrderDto = orderService.placeOrder(orderRequestDto);
		OrderResponseModel placedOrderResponse = mapper.map(placedOrderDto, OrderResponseModel.class);
		return new ResponseEntity<OrderResponseModel>(placedOrderResponse, HttpStatus.CREATED);
	}

	@GetMapping()
	public ResponseEntity<List<OrderResponseModel>> getPreviousOrder(@RequestBody Integer userid) {
		List<OrderDto> orderDtoList = orderService.findPlacedOrder(userid.longValue());
		List<OrderResponseModel> orderResponseList = new ArrayList<OrderResponseModel>();
		ModelMapper mapper = new ModelMapper();
		for (OrderDto orderDto : orderDtoList) {
			OrderResponseModel orderResponseModel = mapper.map(orderDto, OrderResponseModel.class);
			orderResponseList.add(orderResponseModel);
		}
		return new ResponseEntity<List<OrderResponseModel>>(orderResponseList, HttpStatus.FOUND);
	}
}
