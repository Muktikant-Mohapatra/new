package com.abc.orderService.model.request;

import java.util.List;

public class OrderRequestModel {
	private long userId;
	private List<String> itemCode;
	private UserAddressRequestModel address;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public List<String> getItemCode() {
		return itemCode;
	}

	public void setItemCode(List<String> itemCode) {
		this.itemCode = itemCode;
	}

	public UserAddressRequestModel getAddress() {
		return address;
	}

	public void setAddress(UserAddressRequestModel address) {
		this.address = address;
	}

}
