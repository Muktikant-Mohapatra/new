package com.abc.orderService.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.abc.orderService.model.response.UserResponseModel;


@FeignClient("Login")
public interface UserService {
	@GetMapping("/users/{id}")
	public ResponseEntity<UserResponseModel> getUser(@PathVariable("id") long id) ;
}
