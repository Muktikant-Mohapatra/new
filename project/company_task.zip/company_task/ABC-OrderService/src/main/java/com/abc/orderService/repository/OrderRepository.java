package com.abc.orderService.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.abc.orderService.entity.OrderEntity;

public interface OrderRepository extends PagingAndSortingRepository<OrderEntity, Long>{

}
