package com.abc.orderService.dto;

import java.util.List;

import com.abc.orderService.model.request.UserAddressRequestModel;

public class OrderRequestDto {
	private long userId;
	private List<Long> itemCode;
	private UserAddressRequestModel address;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public List<Long> getItemCode() {
		return itemCode;
	}

	public void setItemCode(List<Long> itemCode) {
		this.itemCode = itemCode;
	}

	public UserAddressRequestModel getAddress() {
		return address;
	}

	public void setAddress(UserAddressRequestModel address) {
		this.address = address;
	}

}
