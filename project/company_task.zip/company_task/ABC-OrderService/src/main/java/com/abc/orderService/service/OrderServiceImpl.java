package com.abc.orderService.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.abc.orderService.dao.OrderDao;
import com.abc.orderService.dto.OrderDto;
import com.abc.orderService.entity.ItemEntity;
import com.abc.orderService.entity.OrderEntity;
import com.abc.orderService.entity.UserEntity;
import com.abc.orderService.model.request.OrderRequestModel;
import com.abc.orderService.model.response.ItemResponseModel;
import com.abc.orderService.model.response.UserResponseModel;

@Service
public class OrderServiceImpl implements OrderService {

	private OrderDao orderDao;
	private UserService userService;
	private ItemService itemService;

	@Autowired

	public OrderServiceImpl(OrderDao orderDao, UserService userService, ItemService itemService) {
		super();
		this.orderDao = orderDao;
		this.userService = userService;
		this.itemService = itemService;
	}

	@Override
	public OrderDto placeOrder(OrderRequestModel orderRequestDto) {
		ModelMapper mapper = new ModelMapper();
		OrderEntity orderEntity = new OrderEntity();
		orderEntity.setOrderId("ODR-" + new Random());
		orderEntity.setOrderDate(new Date(System.currentTimeMillis()));
		ResponseEntity<UserResponseModel> responseEntityUserModel = userService.getUser(orderRequestDto.getUserId());
		UserResponseModel userModel = responseEntityUserModel.getBody();
		UserEntity user = mapper.map(userModel, UserEntity.class);
		orderEntity.setUsers(user);
		for (String itemCode : orderRequestDto.getItemCode()) {
			ResponseEntity<ItemResponseModel> responseItemModel = itemService.getItem(itemCode);
			ItemResponseModel itemModel = responseItemModel.getBody();
			ItemEntity item = mapper.map(itemModel, ItemEntity.class);
			orderEntity.addItem(item);
		}
		OrderEntity placedOrderEntity = orderDao.save(orderEntity);
		OrderDto placedOrderDto = mapper.map(placedOrderEntity, OrderDto.class);
		return placedOrderDto;
	}

	@Override
	public List<OrderDto> findPlacedOrder(Long userid) {
		List<OrderDto> orderDtoList = new ArrayList<OrderDto>();
		List<OrderEntity> orderEntityList = orderDao.findByUsers(userid);
		ModelMapper mapper = new ModelMapper();
		for (OrderEntity orderEntity : orderEntityList) {
			OrderDto orderDto = mapper.map(orderEntity, OrderDto.class);
			orderDtoList.add(orderDto);
		}
		return orderDtoList;
	}
}
