package com.abc.orderService.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.abc.orderService.model.response.ItemResponseModel;



@FeignClient(name = "ITEM-SERVICE")
public interface ItemService {
	@GetMapping(value = "/{icode}", produces = { MediaType.APPLICATION_JSON_VALUE,
                                               MediaType.APPLICATION_XML_VALUE, }, 
                                  consumes = { MediaType.APPLICATION_JSON_VALUE,
                                               MediaType.APPLICATION_XML_VALUE, })
public ResponseEntity<ItemResponseModel> getItem(@PathVariable("icode") String icode) ;

}
