package com.abc.orderService.dto;

import java.util.Date;

public class OrderDto {
	private long orderId;
	private Date orderDate;
	private int orderAmount;
	private UserDto userId;
	private ItemDto itemId;

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public int getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(int orderAmount) {
		this.orderAmount = orderAmount;
	}

	public UserDto getUserId() {
		return userId;
	}

	public void setUserId(UserDto userId) {
		this.userId = userId;
	}

	public ItemDto getItemId() {
		return itemId;
	}

	public void setItemId(ItemDto itemId) {
		this.itemId = itemId;
	}

}
