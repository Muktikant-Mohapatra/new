package com.abc.orderService.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.abc.orderService.entity.OrderEntity;
import com.abc.orderService.repository.OrderRepository;

@Repository
public interface OrderDao extends OrderRepository {
	//@Query("select orderId,orderDate,orderAmount,userId where user_id=:userid ")
	List<OrderEntity> findByUsers(Long userid);

}
