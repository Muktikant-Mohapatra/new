package com.abc.orderService.model.response;

import java.util.Date;
import java.util.List;

public class OrderResponseModel {
	private long userId;
	private List<Long> itemCode;
	private long orderCode;
	private Date orderDate;
	private UserAddressResponseModel address;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public List<Long> getItemCode() {
		return itemCode;
	}

	public void setItemCode(List<Long> itemCode) {
		this.itemCode = itemCode;
	}

	public long getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(long orderCode) {
		this.orderCode = orderCode;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public UserAddressResponseModel getAddress() {
		return address;
	}

	public void setAddress(UserAddressResponseModel address) {
		this.address = address;
	}

}
