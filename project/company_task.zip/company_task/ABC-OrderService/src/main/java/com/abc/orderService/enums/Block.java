package com.abc.orderService.enums;

public enum Block {
	BLOCKED, UNBLOCKED;
}
