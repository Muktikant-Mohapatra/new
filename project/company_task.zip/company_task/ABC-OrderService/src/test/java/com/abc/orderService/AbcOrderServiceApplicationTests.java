package com.abc.orderService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcOrderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
