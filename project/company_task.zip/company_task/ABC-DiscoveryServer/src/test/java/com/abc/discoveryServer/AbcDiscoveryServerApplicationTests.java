package com.abc.discoveryServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
