package com.abc.login.security;

public class SecurityConstraints {
public static final String[] PERMIT_ALL_URL= {"/login"};
public static final String[] ADMIN_PERMIT_URL= {"/admins/*"};
public static final String[] USER_PERMIT_URL = {"/users/*"};
public static final long TOKEN_EXPIRATION_TIME=864000000l;
public static final String TOKEN_PREFIX="bearer";
public static final String HEADER_STRING="Authorization";
public static final String TOKEN_SECRET="kjafhakdjhakd5343543";

}
