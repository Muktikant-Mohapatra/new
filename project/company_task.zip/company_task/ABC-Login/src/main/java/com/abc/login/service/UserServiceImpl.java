package com.abc.login.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.login.dao.UserDao;
import com.abc.login.dto.UserDto;
import com.abc.login.entity.UserEntity;

@Service
public class UserServiceImpl implements UserService {
	private UserDao userDao;

	@Autowired
	public UserServiceImpl(UserDao userDao) {
		super();
		this.userDao = userDao;
	}

	@Override
	public UserDto getUser(long id) {
		Optional<UserEntity> findById = userDao.findById(id);
		UserEntity userEntity = findById.get();
		ModelMapper mapper = new ModelMapper();
		UserDto userDto = mapper.map(userEntity, UserDto.class);
		return userDto;
	}
}
