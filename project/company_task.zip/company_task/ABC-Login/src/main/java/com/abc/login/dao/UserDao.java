package com.abc.login.dao;

import org.springframework.stereotype.Repository;

import com.abc.login.entity.UserEntity;
import com.abc.login.repository.UserRepository;

@Repository
public interface UserDao extends UserRepository {

	UserEntity findByEmail(String email);

}
