package com.abc.login.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.login.dto.UserDto;
import com.abc.login.model.response.UserResponseModel;
import com.abc.login.service.UserService;

@RestController
@RequestMapping(value = "/users/")
public class UserController {
	private UserService userService;

	@Autowired
	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	@GetMapping("/{id}")
	public ResponseEntity<UserResponseModel> getUser(@PathVariable("id") long id) {
		UserDto userDto = userService.getUser(id);
		ModelMapper mapper = new ModelMapper();
		UserResponseModel userResponseModel = mapper.map(userDto, UserResponseModel.class);
		return new ResponseEntity<UserResponseModel>(userResponseModel, HttpStatus.FOUND);

	}
}
