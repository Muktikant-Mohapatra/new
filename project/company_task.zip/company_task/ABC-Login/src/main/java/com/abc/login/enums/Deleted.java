package com.abc.login.enums;

public enum Deleted {
	DELETED, NOT_DELETED;
}
