package com.abc.login.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.abc.login.dto.UserDto;

public interface LoginService extends UserDetailsService {

	UserDto findByEmail(String userName);

}
