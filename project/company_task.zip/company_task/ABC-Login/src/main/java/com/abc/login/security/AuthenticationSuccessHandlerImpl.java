package com.abc.login.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.abc.login.service.ItemService;

@Component
public class AuthenticationSuccessHandlerImpl extends SimpleUrlAuthenticationSuccessHandler {
	@Autowired
	private ItemService itemService;

	public AuthenticationSuccessHandlerImpl() {
		super();
	}

	/*
	 * @Autowired public AuthenticationSuccessHandlerImpl(ItemService itemService) {
	 * super(); this.itemService = itemService; }
	 */

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		System.out.println("success:::::::::::::::::::::::::::::::::");
		
		itemService.getItems();
	}
}
