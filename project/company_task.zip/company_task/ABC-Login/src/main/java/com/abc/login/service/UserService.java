package com.abc.login.service;

import com.abc.login.dto.UserDto;

public interface UserService {

	UserDto getUser(long id);

}
