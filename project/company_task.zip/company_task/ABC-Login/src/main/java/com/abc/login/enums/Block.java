package com.abc.login.enums;

public enum Block {
	BLOCKED, UNBLOCKED;
}
