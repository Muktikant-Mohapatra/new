package com.abc.login.service;

import java.util.ArrayList;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.abc.login.dao.UserDao;
import com.abc.login.dto.UserDto;
import com.abc.login.entity.UserEntity;

@Service
public class LoginServiceImpl implements LoginService {
	//private AuthenticationManager authenticationManager;
	private UserDao userDao;

	@Autowired
	public LoginServiceImpl(UserDao userDao) {
		super();
		this.userDao = userDao;
		//this.authenticationManager = authenticationManager;
	}

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		UserEntity userEntity = userDao.findByEmail(email);
		if (userEntity == null)
			throw new UsernameNotFoundException(email);

		return new User(userEntity.getEmail(), userEntity.getPassword(), new ArrayList<>());
	}

	@Override
	public UserDto findByEmail(String email) {
		UserEntity userEntity = userDao.findByEmail(email);
		ModelMapper mapper = new ModelMapper();
		UserDto returnValue = mapper.map(userEntity, UserDto.class);
		return returnValue;
	}

}
