package com.abc.item.service;

import java.util.List;

import com.abc.item.dto.ItemDto;

public interface ItemService {

	ItemDto retriveItem(String itemCode);

	List<ItemDto> retriveAllItems();

}
