package com.abc.item.controller;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.item.dto.ItemDto;
import com.abc.item.response.ItemResponseModel;
import com.abc.item.service.ItemService;

@RestController
@RequestMapping("/items")
public class ItemController {

	private ItemService itemService;

	@Autowired
	public ItemController(ItemService itemService) {
		super();
		this.itemService = itemService;
	}

	@GetMapping()
	public ResponseEntity<List<ItemResponseModel>> getAllItems() {
		List<ItemDto> itemListDto = itemService.retriveAllItems();

		if (itemListDto != null) {
			ModelMapper mapper = new ModelMapper();
			List<ItemResponseModel> itemResponseModelList=new ArrayList<ItemResponseModel>();
			for (ItemDto itemDto : itemListDto) {
				itemResponseModelList.add(mapper.map(itemDto, ItemResponseModel.class));
			}
			return new ResponseEntity<List<ItemResponseModel>>(itemResponseModelList, HttpStatus.FOUND);
		}
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}

	@GetMapping(value = "/{icode}", produces = { MediaType.APPLICATION_JSON_VALUE,
			                                   MediaType.APPLICATION_XML_VALUE, }, 
			                      consumes = { MediaType.APPLICATION_JSON_VALUE,
					                           MediaType.APPLICATION_XML_VALUE, })
	public ResponseEntity<ItemResponseModel> selectItem(@PathVariable("icode") String icode) {
		ItemDto selectedItemDto = itemService.retriveItem(icode);

		if (selectedItemDto != null) {
			ModelMapper mapper = new ModelMapper();
			ItemResponseModel selectedItemResponse = mapper.map(selectedItemDto, ItemResponseModel.class);
			return new ResponseEntity<ItemResponseModel>(selectedItemResponse, HttpStatus.FOUND);
		}
		return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
	}

}
