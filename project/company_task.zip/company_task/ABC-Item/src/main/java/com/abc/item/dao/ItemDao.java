package com.abc.item.dao;

import org.springframework.stereotype.Repository;

import com.abc.item.entity.ItemEntity;
import com.abc.item.repository.ItemRepository;

@Repository
public interface ItemDao extends ItemRepository {

	ItemEntity findByItemCode(String itemCode);

}
