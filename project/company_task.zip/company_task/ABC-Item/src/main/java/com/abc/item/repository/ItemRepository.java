package com.abc.item.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.abc.item.entity.ItemEntity;

public interface ItemRepository extends PagingAndSortingRepository<ItemEntity, Long>{

}
