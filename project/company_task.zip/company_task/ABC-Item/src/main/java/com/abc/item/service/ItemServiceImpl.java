package com.abc.item.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.item.dao.ItemDao;
import com.abc.item.dto.ItemDto;
import com.abc.item.entity.ItemEntity;

@Service
public class ItemServiceImpl implements ItemService {
	private ItemDao itemDao;

	@Autowired
	public ItemServiceImpl(ItemDao itemDao) {
		super();
		this.itemDao = itemDao;
	}

	ModelMapper mapper = new ModelMapper();

	@Override
	public ItemDto retriveItem(String itemCode) {
		ItemEntity itemEntity = itemDao.findByItemCode(itemCode);
		ItemDto itemDto = mapper.map(itemEntity, ItemDto.class);
		return itemDto;
	}

	@Override
	public List<ItemDto> retriveAllItems() {
		List<ItemEntity> itemEntityList = (List<ItemEntity>) itemDao.findAll();
		if (itemEntityList != null) {
			List<ItemDto> itemDtoList = new ArrayList<ItemDto>();
			for (ItemEntity itemEntity : itemEntityList) {
				itemDtoList.add(mapper.map(itemEntity, ItemDto.class));
			}
			return itemDtoList;
		}

		return null;
	}
}
